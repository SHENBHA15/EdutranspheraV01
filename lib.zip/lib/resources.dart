class ImageResource {
  static String logoImage = 'assets/logo.png';
  static String busImage = 'assets/bus.png';
}
